#include <stdio.h>
#include <stdlib.h>

#include "snake.h"

#include "snake_arithmetic.h"
#include "struct_stack.h"
#include "struct_queue.h"

LinkQueue_t SnakeQueue;

unsigned char QueueInit(LinkQueue_t *Q)//��������
{
	Q->front=Q->rear=NULL;
	Q->QueueSize = 0;
	return 1;
}


 
unsigned char QueueIn(LinkQueue_t *Q, signed int SegLen,unsigned char SegDirect)//��Ԫ�ز������
{ 
	QueuePtr p;
	//OSSchedLock();
	p = (QueuePtr)malloc(sizeof(QNode_t));
	//OSSchedUnlock();
	if(!p) 
		return 0;

	p->SnkSeg.SegLen = SegLen;
	p->SnkSeg.SegDirect = SegDirect;

	if(Q->rear == NULL)
	{
		Q->front = p;
		Q->rear = p;
	}
	else
	{
		Q->rear->next=p;       //front�ſգ���һ��������
		Q->rear=p;
	}
	
	p->next = NULL;

	Q->QueueSize++;
	 return 1;
}


snkseg_t *QueueDel(snkseg_t* snksegptr,LinkQueue_t *Q)//��Ԫ�س����ҷ���Ԫ��,ɾ��Ԫ��
{   
	//static snkseg_t snkseg_tmp;
	
    QueuePtr p,q;
	
	p = Q->front;
	q = Q->front->next;

	if(p == NULL)
	{
		return(NULL);
	}
	else
	{
		/* �ݴ��βԪ���Ա㷵�� */
		snksegptr->SegLen = p->SnkSeg.SegLen;
		snksegptr->SegDirect = p->SnkSeg.SegDirect;	
	}
	
	if(q == NULL)
	{
		Q->front = NULL;
		Q->rear = NULL;
	}
	else
	{
		Q->front = q;
	}

	free(p);
	Q->QueueSize --;

    return (snksegptr);
}



unsigned char QueueIsNotEmpty(LinkQueue_t *Q)
{
	if( NULL == Q->rear) return(0);

    else return(1);
}

void QueueRev(LinkQueue_t *Q)
{
	Spt_t stkp;
	snkseg_t *tmpp;
	snkseg_t snk;

	stkp = stack_init();

	while(QueueIsNotEmpty(Q))
	{
		QueueDel(&snk,Q);
		stack_push(stkp, &snk);
	}
	

	while(StackIsNotEmpty(stkp))
	{
		tmpp = stack_pop(stkp);
		QueueIn(Q, tmpp->SegLen, tmpp->SegDirect);
	}

	stack_destroy(stkp);
}


