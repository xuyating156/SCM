#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
#include "driver_usart.h"
#include "board.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_adc.h"
#include "usart.h"
#include "SysTick.h"


extern float pwm_rate ;
#define a -(float)((float)4095/(float)3450)
#define b -(float)((a)*(float)3500)

#define VERY_BRIGHT   50
#define LIT_BRIGHT        600
#define MEDI_BRIGHT   1100
#define DARK          2000
#define VERY_DARK     2800
#define MEDI_DARK      3500

void ADC_Config(void);
void ADC_GPIO_Config(void);
void DAC_Config(void);
void DAC_GPIO_Config(void);


//================================================
typedef enum
{
led_light_val,
light_user_val	

}LIGHT_CON_TYPE_T;


u32 light_conversion(u32 light_value,LIGHT_CON_TYPE_T lc)
{
	if(led_light_val==lc)
		return (a*light_value+b);
	else 
	{
		if(light_value<=600&&light_value>=50)
		{
			return 1;
		}
		else if(light_value<=1100&&light_value>=600)
		{
			return 2;
		}
		else if(light_value<=2000&&light_value>=1100)
		{
			return 3;
		}
		else if(light_value<=2800&&light_value>=2000)
		{
			return 4;
		}
		else if(light_value<=3500&&light_value>=2800)
		{
			return 5;
		}
	}
}

  void DAC_Config(void)
  {
	  DAC_InitTypeDef DAC_InitStructure;

	  RCC_APB2PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
	  DAC_InitStructure.DAC_Trigger = DAC_Trigger_None;
	  DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
	  DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
	  DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
	  // �ر� ��� ���� 
      DAC_Init(DAC_Channel_1,&DAC_InitStructure);
	  DAC_Cmd(DAC_Channel_1,ENABLE);
	//  DAC_SetChannel1Data(DAC_Align_12b_R,2048);

  }


  void ADC_Config(void)
  {
// ����ADC1 
	  ADC_InitTypeDef ADC_InitStructure;
 // ʱ������
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
      RCC_ADCCLKConfig(RCC_PCLK2_Div6);// 72 MHz / 6 

 // ��ʼ��
	  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;//����ģʽ
	  ADC_InitStructure.ADC_ScanConvMode = DISABLE;//ɨ��ת���ر�
	  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;  //����ת��ģʽ
	  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//�����ⲿ�¼�����ת��
	  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; //���ݶ���Ϊ�Ҷ���
	  ADC_InitStructure.ADC_NbrOfChannel = 1;//����ͨ�����г���Ϊ1
      ADC_Init(ADC1, &ADC_InitStructure);
	  
//ʹ��ADC�жϣ���DMA��ʽ��
	ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);
	  

	  
// ����ADC����ʱ�䣬ת������	 ADC1����ͨ������  
	 ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_239Cycles5);
      //  (  x + 12.5 ) / 12 M 

	  
	  // ����ADC��NVIC�ж�
	   NVIC_InitTypeDef NVIC_InitStructure;
	  // ���ò�����ADC�ж�
	   NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
	   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	   NVIC_Init(&NVIC_InitStructure);
  
// ʹ��ADC
	  ADC_Cmd(ADC1, ENABLE);
  
//У׼ADC
  ADC_ResetCalibration(ADC1);// ��λ
  while(SET == ADC_GetResetCalibrationStatus(ADC1));
  ADC_StartCalibration(ADC1);// ����Ƿ�λ
  
   
  while(SET == ADC_GetCalibrationStatus(ADC1));//�������У׼

       ADC_StartCalibration(ADC1);// ����Ƿ�λ

  
// ��ʼADCת��
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);




  }

  void ADC_GPIO_Config(void)
  {
	  GPIO_InitTypeDef GPIO_InitStructure;
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 ;
	  GPIO_InitStructure.GPIO_Mode= GPIO_Mode_AIN;
	  //����ΪADCͨ�� ��������
	  GPIO_Init(GPIOC, &GPIO_InitStructure);
  
  
  }

  //  ����PC.04��ADCͨ��14�� 
  
  void DAC_GPIO_Config(void)
  {
	  GPIO_InitTypeDef GPIO_InitStructure;
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 ;
	  GPIO_InitStructure.GPIO_Mode= GPIO_Mode_AIN;
	  //����ΪADCͨ�� ��������	
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  
  }

  
  static uint16_t Value=0;

  //�жϴ���
  void ADC1_2_IRQHandler(void)
  {
	  
	  // �ж��Ƿ� �� ADC1
	  if(SET==ADC_GetITStatus(ADC1,ADC_IT_EOC))
	  {
	  // ���ADC1 EOC�����ж�λ��
	  ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);// ����ж�λ
	  // �õ���ADC1ת����ͨ��14��ת��ֵ
	  Value = ADC_GetConversionValue(ADC1);
		//printf("%d\r\n",Value);
		
	//	Sys_DelaynMs(1000);
	  }
  }
  
  int main(void)	  
  {
  
	 u32 led_light_value=0;
	 u32 led_light_suer=0;
  
	  board_init();
	  
	  uart_init(115200);
      ADC_GPIO_Config();
      DAC_GPIO_Config();
  //  GPIO_SetBits(GPIOC,GPIO_Pin_4);
	//	TIM3_Config(1799,199,PWM_M);// 100us  1800*2 /36 us 
   //	TIM_SetCompare2(TIM3,900);
  
  
  
  
     
      ADC_Config();
	  DAC_Config();
  
  
	  printf("-----smart led-----\r\n");
	  while(1)
	  {
	    
		  led_light_value=light_conversion(Value,led_light_val);
		  led_light_suer=light_conversion(Value,light_user_val);
		  switch(led_light_suer)
		  {
			  case 1:
				  printf("VERY_BRIGHT\r\n");
				  break;
			  case 2:
				  printf("BRIGHT\r\n");
				  break;
			  case 3:
				  printf("MEDI_BRIGHT\r\n");
				  break;
			  case 4:
				  printf("DARK\r\n");
				  break;
			  case 5:
				  printf("VERY_DARK\r\n");
				  break;
		  default :
		  	printf("-----smart led3-----\r\n");
			  break;
  
  
		  }
		  
		 // GPIO_ResetBits(GPIOA,GPIO_Pin_4);
		  DAC_SetChannel1Data(DAC_Align_12b_R,led_light_value);
	   //	delay_ms(1000);
	   Sys_DelaynMs(1000);
	  }
  
	  
  //  return 0;
	}

