#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
#include "driver_usart.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_adc.h"
#include "usart.h"
#include "SysTick.h"
#include "dhtll.h"

int main(void)      
{ 
   dht11_t  my_dht11 ;
   u8 respond_result = 0,wait_count=0,data_get_result=0,i=0,j=0;
   float hds[15]={0},temps[15]={0};
   uart_init(9600);

   SysTick_Init(72);
   dht11_init(&my_dht11);
   printf("------dht11   datd   get  -----\r\n");
   while(1)// ��ѯ��
   {
	   dht11_requested(my_dht11);// ���� 
	   // GPIO�� Ϊ����ģʽ
	  while( 0!=(respond_result=dht11_respond(&my_dht11)))
	  {// ��ʾʧ��  �ȴ�������ȷ��ֵ 0  
		  if(1==respond_result)
			{
				printf("respond error.\r\n");
			    delay_us(1000);
			}

		  else 
		  	printf("data send per error.\r\n");
		  delay_us(1000);
		  dht11_respond(&my_dht11); // �ٴ�����
		  if(3==wait_count++)
		  	{// �Լ����޸�  ����һ������ 
			  printf("please checkother reason,and reset again.\r\n");
			  return 0;
		     }
		  wait_count=0;
	  }

	  
     while( 0!=(data_get_result= dht11_data_get(&my_dht11))); // �շ�����
     {
	 	if(1==respond_result)printf("data get error\r\n");
		else printf("data over error.\r\n");
		delay_us(1000);
		if(3==wait_count++)
		{   i=1;
			break;
        }
	 }


  if(i)
  	{
	  		if(0==dht11_data_check(my_dht11))
			{
				printf("hd:%d,%d------temp:%d,%d\r\n",
					my_dht11.hd_1,my_dht11.hd_2,my_dht11.temp_1,my_dht11.temp_2);
				dht11_data_analy(&my_dht11);
				hds[j]=my_dht11.hd;
				temps[j]=my_dht11.temp;
				j++;
				if(15==j)
				{
					j=0;
				}
			}
			else
		   printf("check data error.\r\n");

  }
  else
  {
  	
	printf("get data error.\r\n");
  }
  delay_ms(1000);
	 
   }
}


