// data_pin  mode  value 

typedef struct
{      
       GPIO_TypeDef * ping_grop;
       uint16_t pin;
       GPIOMode_TypeDef mode;
	   BitAction value;
       u8 hd_1;
	   u8 hd_2;
	   u8 temp_1;
	   u8 temp_2;
	   u8 check;
	   float hd ;
	   float temp;


}dht11_t;


void dht11_init(dht11_t *my_dht11);
void dht11_requested(dht11_t my_dht11);
	u8 dht11_respond(dht11_t *my_dht11);
	u8 dht11_data_get(dht11_t *my_dht11);
	u8 dht11_data_analy(dht11_t *my_dht11);
	u8 dht11_data_check(dht11_t my_dht11);
	u8 dht11_data_real(dht11_t *my_dht11);
	void Gpio_init(GPIO_TypeDef * ping_grop,uint16_t pin,
				   GPIOMode_TypeDef mode,BitAction value);


