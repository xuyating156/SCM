#ifndef _SYSDELAY_H_
#define _SYSDELAY_H_


extern void Sys_DelaynUs(volatile unsigned int nCount);
extern void Sys_DelaynMs(volatile unsigned int nCount);

#endif
