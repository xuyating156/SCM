#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"


#define  RCC_ADDR_BASE   0X40021000  //��ʼ��ַ
#define  RCC_APB2ENR_OFFSET  0x18  //ƫ����
#define  RCC_APB2ENR_ADDR  (*(volatile unsigned int *)(RCC_ADDR_BASE+RCC_APB2ENR_OFFSET))

//CPIO   CPIOB_CEL��λ���üĴ���   CPIOb_BSSR ������һλ��д0����д1�ļĴ���
//GPIOE_ADDR  GPIO_BSSR  LED6  LED7
#define CPIOF_ADDR_BASE  0x40011C00
#define CPIOF_CRL_OFFSET  0x00//ÿ��ƫ��������ͬ
#define CPIOF_CRH_OFFSET  0x04
#define CPIOF_BSRR_OFFSET  0x10

#define  CPIOF_CRL_ADDR6 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_CRL_OFFSET))
#define  CPIOF_BSSR_ADDR6 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_BSRR_OFFSET))

#define  CPIOF_CRL_ADDR7 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_CRL_OFFSET))
#define  CPIOF_BSSR_ADDR7 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_BSRR_OFFSET))

#define  CPIOF_CRH_ADDR8 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_CRH_OFFSET))
#define  CPIOF_BSSR_ADDR8 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_BSRR_OFFSET))

#define  CPIOF_CRH_ADDR9 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_CRH_OFFSET))
#define  CPIOF_BSSR_ADDR9 (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_BSRR_OFFSET))

void delay(int time)
{

int i,j;
for(i=0;i<time;i++)
	for(j=0;j<1000;j++);
}


int main()
{



  GPIO_InitTypeDef led={0}��button={0};
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF|RCC_APB2Periph_GPIOG,ENABLE);//��ʱ�� �൱��RCC_APB2ENR
  //RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG,ENABLE);//��ʱ�� �൱��RCC_APB2ENR

  led.GPIO_Mode = GPIO_Mode_Out_PP;//�������
  led.GPIO_Pin = GPIO_Pin_6;//6������
  led.GPIO_Speed=GPIO_Speed_50MHz;
  
 // button.GPIO_Mode = GPIO_Mode_IPU;
 // button.GPIO_Pin = GPIO_Pin_8;
  
  GPIO_Init(GPIOF,&led);
//  GPIO_Init(GPIOF,&button);
/*  while(1)
  {
    if(0==GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_8))
    { 
	   GPIO_SetBits(GPIOF , GPIO_Pin_6);//�� ��0
    }
     else 
     {
      
	  GPIO_ResetBits(GPIOF , GPIO_Pin_6);//��1
	 }

  }
  */
  led.GPIO_Pin = GPIO_Pin_7;
  GPIO_Init(GPIOF,&led);


  led.GPIO_Pin = GPIO_Pin_8;
  GPIO_Init(GPIOF,&led);

   led.GPIO_Pin = GPIO_Pin_9;
   GPIO_Init(GPIOF,&led);

while(1) 
	{
  
  GPIO_SetBits(GPIOF , GPIO_Pin_6);//�� ��0
  delay(500);
  GPIO_ResetBits(GPIOF , GPIO_Pin_6);//��1

 
  GPIO_SetBits(GPIOF , GPIO_Pin_7);//��
  delay(500);
  GPIO_ResetBits(GPIOF , GPIO_Pin_7);

  
  GPIO_SetBits(GPIOF , GPIO_Pin_8);//��
  delay(500);
  GPIO_ResetBits(GPIOF , GPIO_Pin_8);

  GPIO_SetBits(GPIOF , GPIO_Pin_9);//��
  //GPIO_WriteBit( GPIOF,GPIO_Pin_9,Bit_SET)
  delay(500);
  GPIO_ResetBits(GPIOF , GPIO_Pin_9);
  }
  


  return 0;
}
