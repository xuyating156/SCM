#ifndef _STRUCTSTACK_H_
#define _STRUCTSTACK_H_

struct stacktou
{
	struct stacknod* bottom;
	struct stacknod* top;
	int StackSize;
};

struct stacknod
{
	snkseg_t SnkSeg;
	struct stacknod* next;
};

typedef struct stacktou* Spt_t;
typedef struct stacknod* Sp_t;

extern Spt_t stack_init(void); 
extern Spt_t stack_push(Spt_t tou,snkseg_t *snksegPtr);
extern snkseg_t * stack_pop(Spt_t tou);
extern void stack_destroy(Spt_t tou);
extern unsigned char StackIsNotEmpty(Spt_t tou);
#endif
