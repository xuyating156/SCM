#include "stm32f10x.h"

#include <stdlib.h>

#include "snake.h"

#include "snake_arithmetic.h"
#include "struct_stack.h"
#include "struct_queue.h"



Spt_t stack_init(void)
{
	Spt_t p;

	//OSSchedLock();
	p = malloc(sizeof(struct stacktou));
	//OSSchedUnlock();

	
	p->bottom=NULL;
	p->top=NULL;

	p->StackSize = 0;

	return p;
}

Spt_t stack_push(Spt_t tou,snkseg_t *snksegPtr)
{  
	Spt_t p=tou;
	Sp_t q;

	//OSSchedLock();
	q=malloc(sizeof(struct stacknod));
	//OSSchedUnlock();


	q->SnkSeg.SegLen 	= snksegPtr->SegLen;
	q->SnkSeg.SegDirect = snksegPtr->SegDirect;
	
	q->next=p->top;
	p->top=q;

	tou->StackSize++;
	return tou;
}

snkseg_t * stack_pop(Spt_t tou)
{
	Spt_t p;
	Sp_t tmpp;

	static snkseg_t snksegtmp;
	
	p = tou;
	
	snksegtmp.SegDirect = (p->top->SnkSeg).SegDirect;
	snksegtmp.SegLen    = (p->top->SnkSeg).SegLen;
	
	tmpp = p->top;
	
	if(p->top != p->bottom)
	{
		p->top = p->top->next;

		//OSSchedLock();
		free(tmpp);
		//OSSchedUnlock();
		
		tou->StackSize--;

	} 

	return(&snksegtmp);
}

void stack_destroy(Spt_t tou)
{
	//OSSchedLock();
	free(tou);
	//OSSchedUnlock();
}

u8 StackIsNotEmpty(Spt_t tou)
{
	if(tou->top == tou->bottom) return(0);
	else return(1);
}

