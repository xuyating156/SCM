#
#include "stm32f10x.h"
#include "stm32f10x_it.h"
//============================

#include "types.h"
#include "sys_delay.h"
#include "driver_usart.h"
#include "board.h"
#include "stm32f10x_tim.h"

extern float pwm_rate ;
//================================================
int main(void)      
{
	float i  =0;
	board_init();
	USART1_Config(115200);
	TIM2_Config(1799,1,IC_IT_M);
//	TIM2_Config(179,1,IC_IT_M);

//	TIM3_Config(1799,199,PWM_M);// 100us  1800*2 /36 us 
//	PrintfUsart1("hello stm32\r\n");

    // ���ϸı�Ƚ�ֵCCRx���ﵽ��ͬ��ռ�ձ�Ч��

	while(1);
   
/*	    
	    for(i=1799;i>=0;i-=50)
	    {
			TIM_SetCompare2(TIM3,i);// �ڶ���ֵ  ����0  С�� ARR
	        Sys_DelaynMs(50);
			//OSTimeDlyHMSM(0,0,0,20);
		 }
	    for(i=0;i<=1799;i+=50)
	    {
			TIM_SetCompare2(TIM3,i);// �ڶ���ֵ  ����0  С�� ARR
	        Sys_DelaynMs(50);
		//	OSTimeDlyHMSM(0,0,0,20);
		 }

*/

	
	
	return 0;
  }





