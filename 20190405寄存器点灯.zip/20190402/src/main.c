//RCC  RCC_APB2ENR  SIB3  1
#define  RCC_ADDR_BASE   0X40021000  //��ʼ��ַ
#define  RCC_APB2ENR_OFFSET  0x18  //ƫ����
#define  RCC_APB2ENR_ADDR  (*(volatile unsigned int *)(RCC_ADDR_BASE+RCC_APB2ENR_OFFSET))

//CPIO   CPIOB_CEL��λ���üĴ���   CPIOb_BSSR ������һλ��д0����д1�ļĴ���
/*
#define CPIOB_ADDR_BASE  0x40010C00
#define CPIOB_CEL_OFFSET  0x00
#define CPIOB_BSRR_OFFSET  0x10

#define  CPIOB_CRL_ADDR (*(volatile unsigned int *)(CPIOB_ADDR_BASE+CPIOB_CEL_OFFSET))
#define  CPIOB_BSSR_ADDR (*(volatile unsigned int *)(CPIOB_ADDR_BASE+CPIOB_BSRR_OFFSET))
*/

#define CPIOF_ADDR_BASE  0x40011C00
#define CPIOF_CRL_OFFSET  0x00//ÿ��ƫ��������ͬ
#define CPIOF_BSRR_OFFSET  0x10

#define  CPIOF_CRL_ADDR (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_CRL_OFFSET))
#define  CPIOF_BSSR_ADDR (*(volatile unsigned int *)(CPIOF_ADDR_BASE+CPIOF_BSRR_OFFSET))





int main()
{
  // volatile unsigned int *rcc_apb2enr=(unsigned int *)RCC_APB2ENR_ADDR;
  // volatile unsigned int *gpiob_crl=(unsigned int *)CPIOB_CRL_ADDR;
   //volatile unsigned int *gpiob_bssr=(unsigned int *)CPIOB_BSSR_ADDR;

  RCC_APB2ENR_ADDR= 0x00000008;//0x00000008   ����λ�ı�
 // CPIOB_CRL_ADDR =0x00300000;//0x00300000  
 // CPIOB_BSSR_ADDR=0x00000010;//0000 0000 0000 0000 0000 0000 0001 0000
 CPIOF_CRL_ADDR=0x03000000;//
 CPIOF_BSSR_ADDR=0x00000040;//

  return 0;
}
