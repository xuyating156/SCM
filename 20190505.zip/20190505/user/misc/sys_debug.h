#ifndef _SYS_DEBUG_H_
#define _SYS_DEBUG_H_

#ifndef G_SYSDEBUG
	#define G_SYSDEBUG	extern
#endif

#define SYSDEBUG_EN
/*
 * ���ļ�ϵchinmel@163.com��д
 *@20120105
 *
 *
 *STM32���ڴ�ӡ������
 *֧��shellģʽ
 *
 */


//ʹ�÷���:
//��ʼ����sysdebug_init()
//�򿪵���ģʽ: SysDebug_ConsoleEnable()
//��ӡ��ͨ�ַ���: Sysdebug.PrintStr("HELLO WORLD!\r\n");
//��ӡ��ʽ�ַ���: Sysdebug.PrintFormatStr("I am %d years old\r\n", ages);
//��ӡ��ʽ�ַ���: Sysdebug.PrintFormatStr("String is: %s\r\n", strp);


//ע�ⲻ����shellģʽʱ��ز�Ҫ�򿪴˺꿪��
//#define SYSDEBUG_DEBUGMODE_EN

//======================================
#ifdef SYSDEBUG_DEBUGMODE_EN 
#define CMDKEYWORDS_LEN_DEFAULT			10
#define CMDINFO_LEN_DEFAULT			100
#define CMD_MAX_DEFAULT				10

#define USERNAME_LEN_DEFAULT			10
#define USERPWD_LEN_DEFAULT			10

#define USER_GUESTID_DEFAULT			2
#define USER_MAX_DEFAULT			3
#endif

//==========================================

typedef enum
{
	SysDebugType_Console,
	SysDebugType_Gui,
	SysDebugType_DebugMode,
	SysDebugType_Void
	
}SysDebugTypeDef;


#ifdef SYSDEBUG_DEBUGMODE_EN 
typedef enum
{
	SysDebugUserType_Guest,
	SysDebugUserType_Normal,
	SysDebugUserType_Admin
}SysDebugUserTypeDef;



typedef struct
{
	SysDebugUserTypeDef Usertype;
	char UserName[USERNAME_LEN_DEFAULT];
	char UserPwd[USERPWD_LEN_DEFAULT];
}SysDebugUserDef;

typedef struct
{
	char CmdKeyWords[CMDKEYWORDS_LEN_DEFAULT];
	char CmdInfo[CMDINFO_LEN_DEFAULT];
	char *CmdParmsp;
	Boolean (*CmdAction)(char *CmdBufp); 
}SysDebugCmdDef;


#endif

typedef struct
{

#ifdef SYSDEBUG_DEBUGMODE_EN 
	Boolean IsAdminLoginAlready;
	char *LoginUsrStr;
	u8 LoginUsrID;
	#endif
	
	SysDebugTypeDef DebugType;
	void (*PrintStr)(char *Bufp); 
	void (*PrintFormatStr)(u8 *Data,...);	
}SysDebugDef;




G_SYSDEBUG SysDebugDef SysDebug;
G_SYSDEBUG Boolean SysDebug_Init(void);
G_SYSDEBUG Boolean SysDebug_BufFlush(u8 *bufp, u16 *lenp);
G_SYSDEBUG Boolean SysDebug_SetLedBlink(void);
G_SYSDEBUG Boolean SysDebug_GetTaskSta(u16 TaskID);



G_SYSDEBUG Boolean SysDebug_SwitchPrintStrToVoid(void);
G_SYSDEBUG Boolean SysDebug_SwitchPrintFormatStrToVoid(void);

G_SYSDEBUG Boolean SysDebug_CheckLogin(void);
G_SYSDEBUG Boolean SysDebug_CmdSearch(char *CmdBufp);

G_SYSDEBUG Boolean SysDebug_ConsoleEnable(void);
G_SYSDEBUG Boolean SysDebug_ConsoleDisable(void);
G_SYSDEBUG Boolean SysDebug_DebugModeEnable(void);
G_SYSDEBUG Boolean SysDebug_DebugModeDisable(void);
//================================================

G_SYSDEBUG Boolean Asc2Hex(u8 *O_data, u8 *N_data, u16 len); 
G_SYSDEBUG u16 Hex2Asc(u8 *dat, char *buffer, u16 len);
#endif
