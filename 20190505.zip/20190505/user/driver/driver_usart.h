#ifndef _DRIVER_USART_H_
#define _DRIVER_USART_H_

#define USART1_ENABLE


//===========================================
#define USART1_BAND		57600
	
	

//=========================================	
extern void USART1_Config(u32 usart_band);
extern void USART1NVIC_Config(void);

extern void Usart1_Puts(char * str);
extern void Usart1_TransmitData(char * str , u32 len);

extern void PrintfUsart1(unsigned char  *Data,...);

#endif
